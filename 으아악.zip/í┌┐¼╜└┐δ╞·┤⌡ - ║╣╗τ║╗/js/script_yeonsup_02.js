$(document).ready(function(){
	// 1. 탭
	$(".nav>ul>li").mouseover(function(){
		$(this).find(".sub").stop().slideDown(200);
	});
	$(".nav>ul>li").mouseout(function(){
		$(this).find(".sub").stop().slideUp(200);
	});

	// 2. 슬라이드
	var christmas=0;
	setInterval(function(){
		if(christmas<2){
			christmas++
		} else{
			christmas=0;
		}
		var slidePosition = christmas * (-378)+"px"; 
		$(".slideList").animate({top:slidePosition},400); 
	},1000);

	//3. 공지사항 탭메뉴	
	$(".notice>ul>li").click(function(){
		var linum = $(this).index();
		$(".notice>ul>li").removeClass();
		$(this).addClass("active");
		$(".boxWrap>div").hide();
		$(".boxWrap>div").eq(linum).fadeIn();
	});


});